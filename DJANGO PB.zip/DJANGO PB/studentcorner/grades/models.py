from django.db import models

# Create your models here.
class Grade(models.Model):
    name = models.CharField(max_length=200)
    rollno = models.IntegerField()
    sem = models.IntegerField()
    date = models.DateField()
    spi = models.FloatField(blank=True)
